import { useEffect, useState } from "react";
import { getUsers, addUser, updateUser, deleteUser } from "./UserService";

function UserList() {
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState("");

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const data = await getUsers();
    setUsers(data);
  };

  const handleAddUser = async () => {
    if (newUser.trim() == "") return;
    const user = { name: newUser };
    const addedUser = await addUser(user);
    setUsers([...users, addedUser]);
    setNewUser("");
  };

  const handleUpdateUser = async (id) => {
    const updatedUser = { name: prompt("Enter new name:") };
    if (!updatedUser.name) return;
    await updateUser(id, updatedUser);
    setUsers(users.map((user) => (user.id == id ? { ...user, ...updatedUser } : user)));
  };

  const handleDeleteUser = async (id) => {
    await deleteUser(id);
    setUsers(users.filter((user) => user.id != id));
  };

  return (
    <div>
      <h2>Users List</h2>
      <input
        type="text"
        value={newUser}
        onChange={(e) => setNewUser(e.target.value)}
        placeholder="Enter new user"
      />
      <button onClick={handleAddUser}>Add User</button>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            {user.name}
            <button onClick={() => handleUpdateUser(user.id)}>Edit</button>
            <button onClick={() => handleDeleteUser(user.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default UserList;
