import { useState, useEffect } from "react";

function Comp(){
    const [users, setUsers]=useState([]);
    useEffect(() => {
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((response) => response.json())
        .then((users) => setUsers(users))
    }, []);
    return(
       <div>
        <h1>User List</h1>
        {users.length > 0 ? (
            <ul>
                {users.map((users) => (
                    <li key={users.id}>{users.name}</li>
                ))}
            </ul>
        ) :( <p> Loading....</p>)}
       </div> 
    );
}

export default Comp;